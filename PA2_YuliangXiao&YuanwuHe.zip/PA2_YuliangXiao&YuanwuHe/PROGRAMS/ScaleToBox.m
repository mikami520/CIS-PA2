% give bouding box to the point
% Shrink the range of original data set without changing distribution
function u = ScaleToBox(q, qmin, qmax)
    u(1) = (q(1) - qmin(1)) / (qmax(1) - qmin(1));
    u(2) = (q(2) - qmin(2)) / (qmax(2) - qmin(2));
    u(3) = (q(3) - qmin(3)) / (qmax(3) - qmin(3));
end