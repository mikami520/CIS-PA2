%{  Get coefficient of Bernstein polynomials on the input dataset by using least square problem
%   Input: p(set of data without distortion), q(set of data with distortion)
%   Output: c(coefficient of Bernstein polynomials)
%}
function c = getCoefficient(p, q)
    totalF = [];
    % copmute minimum and maximum vector of data set
    qmin = min(q,[],1);
    qmax = max(q,[],1);
    for i = 1:length(q)
        ele = q(i,:);
        % give bounding box to each point
        u = ScaleToBox(ele, qmin, qmax);
        F = [];
        for j = 0:5
            for m = 0:5
                for n = 0:5
                    % compute Fijk = B(ux, i) * B(uy, j) * B(uz, k)
                    f = Bern(u(1), 5, j) * Bern(u(2), 5, m) * Bern(u(3), 5, n);
                    F = [F f];
                end
            end
        end
        totalF = [totalF; F];
    end
    % use least square to compute coefficient of Bernstein polynomials
    cx = lsqr(totalF, p(:,1));
    cy = lsqr(totalF, p(:,2));
    cz = lsqr(totalF, p(:,3));
    c = [cx cy cz];
end

% compute Bernstein element
function v = Bern(x, N, k)
    coef = factorial(N) / (factorial(N-k) * factorial(k));
    v = coef * (1-x)^(N-k) * x^k;
end