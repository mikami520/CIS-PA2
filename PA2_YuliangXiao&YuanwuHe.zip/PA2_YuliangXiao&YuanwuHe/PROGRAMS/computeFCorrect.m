% Compute Fg after distortion correction on the maker of EM probe

function result = computeFCorrect(data_ep, coef_C, N_frame, Ng_ep, qmin, qmax)
%%% correct distortion of makers on EM probe relative to the EM base
    G_cell = cell(N_frame,1);
    en = 0;
    correct = CorrectDistort(data_ep, coef_C, qmin, qmax);
    for i = 1:N_frame
        start = en + 1;
        en = Ng_ep * i;
        % extract EM marker position from each frame
        G = correct(start:en, :);
        % correct distortion on EM marker of the EM probe
        G_cell{i} = G;
    end
    
    % use first frame as reference
    G1 = G_cell{1};
    % compute midpoint of reference frame
    avgG1 = mean(G1,1);
    % compute difference relative to the midpoint
    g1 = G1 - avgG1;
    % construct a cell that store each Fg computed by 3D to 3D registration algorithm
    result = cell(N_frame,1);
    for i = 1:N_frame
        Gele = G_cell{i};
        F = T2TR(g1, Gele);
        result{i} = F;
    end
end