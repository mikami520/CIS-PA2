% { Pivot Calibration Algorithm
%   Input: a cell of all frame noted Fmatrix
%   Output: Ppost and Pdimple
% }
function [Pt, Ppivot] = pivotCalibration(Fmatrix)
    A = [];
    B = [];
    % extract each frame the frame cell
    for i= 1:length(Fmatrix)
        F = Fmatrix{i};
        R = F(1:3, 1:3);
        p = F(1:3, 4);
        % apply point pivot calibration
        A = [A; R -eye(3)];
        B = [B; -p];
    end
    % apply least square to obtain P
    P = lsqr(A, B);
    Pt = P(1:3);
    Ppivot = P(4:6);
end