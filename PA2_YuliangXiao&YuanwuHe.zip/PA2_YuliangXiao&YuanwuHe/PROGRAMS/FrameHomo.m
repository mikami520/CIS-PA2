% { Homogeneous representation of frame F
%   Input: 3*3 rotation matrix, 3*1 translation vector
%   Output: homogeneous representation of frame F
% }
function F = FrameHomo(R, p)
    F = [R p; zeros(1,3) 1];
end