mkdir('TEST')
expectD = importdata('testDistortCorrect_ExpectData.txt');
trueD = importdata('testDistortCorrect_DistortionData.txt');
% test getCoefficient()
coef = getCoefficient(expectD, trueD);
dmin = min(trueD,[],1);
dmax = max(trueD,[],1);
% test CorrectDistort()
result = CorrectDistort(trueD, coef, dmin, dmax);
% compare the result with expected data
figure;
plot3(expectD(:,1),expectD(:,2),expectD(:,3),'b*');
hold on
plot3(result(:,1),result(:,2),result(:,3),'r.');
% save the file to the TEST folder
FULLDATA = result';
file_name = './TEST/test-output.txt';
fileID = fopen(file_name,'wt+');
fprintf(fileID,'%.2f %.2f %.2f\n',FULLDATA);
fclose(fileID);

