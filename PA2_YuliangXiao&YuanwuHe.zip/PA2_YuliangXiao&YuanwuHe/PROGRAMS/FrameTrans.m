% { frame transformaton
%   Input: frame F1, frame F2
%   Output: RotTrans: rotation matrix of frame after frame transformation
%           TranTrans: translation vector of frame after frame transformation
%           FrameTr: result frame after frame transformation
% }

function [RotTrans, TranTrans, FrameTr] = FrameTrans(F1, F2)
    R1 = F1(1:3,1:3);
    p1 = F1(1:3, 4);
    R2 = F2(1:3,1:3);
    p2 = F2(1:3, 4);
    RotTrans = R1 * R2;
    TranTrans = R1 * p2 + p1;
    FrameTr = FrameHomo(RotTrans, TranTrans);
end