clc
clear all
debug = ['a','b','c','d','e','f'];
unknown = ['g','h','i','j'];
mkdir('OUTPUTS');

for i=1:length(debug)
    x = 'debug';
    k = debug(i);
    main(x,k);
end


for j = 1:length(unknown)
    x = 'unknown';
    k = unknown(j);
    main(x,k);
end

function main(x,k)
        %%% compute expect C
        %%% input file which describes the calibration object
        filename_1 = ['pa2-',x,'-',k,'-calbody.txt'];
        table_cb = importdata(filename_1);
        data_cb = table_cb.data;
        textdata_cb = table_cb.textdata{1};
        Nd_cb = str2double(textdata_cb(1));
        Na_cb = str2double(textdata_cb(4));
        Nc_cb = str2double(textdata_cb(7:8));

        data_d = data_cb(1:Nd_cb,:);
        data_a = data_cb(Nd_cb+1:Nd_cb+Na_cb,:);
        data_c = data_cb(Nd_cb+Na_cb+1:size(data_cb,1),:);

        %%% input file which provides the values read by the sensor
        filename_2 = ['pa2-',x,'-',k,'-calreadings.txt'];
        table_cr = importdata(filename_2);
        data_cr = table_cr.data;
        textdata_cr = table_cr.textdata{1};
        ND_cr = str2double(textdata_cr(1));
        NA_cr = str2double(textdata_cr(4));
        NC_cr = str2double(textdata_cr(7:8));
        num_frame = str2double(textdata_cr(11:13));

        %%% Calculation of C^expected
        en = 0;
        expectC = [];
        trueC = [];
        for i = 1:num_frame
            start = en + 1;
            en = i * (ND_cr + NA_cr + NC_cr);
            data_D = data_cr(start:start+ND_cr-1,:);
            data_A = data_cr(start+ND_cr:start+ND_cr+NA_cr-1,:);
            data_C = data_cr(start+ND_cr+NA_cr:en,:);
            trueC = [trueC; data_C];
            FD = T2TR(data_d, data_D);
            FA = T2TR(data_a, data_A);
            [~, ~, infD] = InvF(FD);
            [~, ~, Ftrans] = FrameTrans(infD, FA);
            for j = 1:length(data_c)
                [~, transc] = TriDxform(Ftrans, data_c(j, :)');
                expectC = [expectC; transc'];
            end
        end
        %%% compute coefficient of distortion correction function for each frame
        en1 = 0;
        coef_C = [];
        for i=1:num_frame
            start1 = en1+1;
            en1 = i*NC_cr;
            coef = getCoefficient(expectC(start1:en1,:), trueC(start1:en1,:));
            coef_C = [coef_C; coef];
        end
        
        
        %%% repeat pivot calibration with EM probe after correct distortion
        %%% import EM pivot data 
        %%% input file which provides the values read by the sensor
        filename_3 = ['pa2-',x,'-',k,'-empivot.txt'];
        table_ep = importdata(filename_3);
        data_ep = table_ep.data;
        textdata_ep = table_ep.textdata;
        Ng_ep = str2double(textdata_ep(1));
        N_frame = str2double(textdata_ep(2));

        Fmatrix = computeFCorrect(data_ep, coef_C, N_frame, Ng_ep);

        % use pivot calibration to get position of pointer tip and pivot
        [Ptip, Ppivot] = pivotCalibration(Fmatrix);
        disp("Estimated post position with EM probe pivot calibration: ");
        disp(Ppivot);
        disp("");

        %%% input file which provides the values read by the sensor
        filename_4 = ['pa2-',x,'-',k,'-optpivot.txt'];
        table_op = importdata(filename_4);
        data_op = table_op.data;
        textdata_op = table_op.textdata{1};

        Nd_op = str2double(textdata_op(1));
        Nh_op = str2double(textdata_op(4));
        N_frame = str2double(textdata_op(7:8));

        % Fd
        new_H = cell(N_frame,1);
        for i = 1:N_frame
            st = (Nd_op + Nh_op) * (i-1) + 1;
            en = st + Nd_op - 1;
            D = data_op(st:en, :);
            H = data_op(en+1:(Nd_op + Nh_op) * i, :);
            Ht = [];
            [~,~,invFd] = InvF(FD);
            for j = 1:Nh_op
                H_ele = H(j, :);
                [~, Ht_ele] = TriDxform(invFd, H_ele');
                Ht = [Ht; Ht_ele'];
            end
            new_H{i} = Ht;
        end

        H1 = new_H{1};
        avgH1 = mean(H1,1);
        h1 = H1 - avgH1;


        Fmatrix = cell(N_frame,1);
        for i = 1:N_frame
            HH = new_H{i};
            Fh = T2TR(h1, HH);
            Fmatrix{i} = Fh;
        end

        [~, Ppivot_opt] = pivotCalibration(Fmatrix)
        
        
        %%% Compute Bj
        filename_5 = ['pa2-',x,'-',k,'-em-fiducialss.txt'];
        table_emf = importdata(filename_5);
        data_emf = table_emf.data;
        textdata_emf = table_emf.textdata;
        Ng_emf = str2double(textdata_emf(1));
        N_frame1 = str2double(textdata_emf(2));
        Fmatrix1 = computeFCorrect(data_emf,coef_C, N_frame1, Ng_emf);
        % compute Bj which is the pointer tip relative to the EM base
        Bj = [];
        for i=1:N_frame1
            F = Fmatrix1{i};
            % Bj = Fg * Ptip
            [~,B] = TriDxform(F, Ptip);
            Bj = [Bj; B'];
        end
        
        
        
        %%% compute Freg
        filename_6 = ['pa2-',x,'-',k,'-ct-fiducials.txt'];
        table_ctf = importdata(filename_6);
        data_ctf = table_ctf.data;
        textdata_ctf = table_ctf.textdata;
        Ng_ctf = str2double(textdata_ctf{1}(1));
        % get bj
        bj = data_ctf;
        % bj = Freg * Bj
        Freg = T2TR(Bj, bj);

        
        
        
        %%% find corresponding position of pointer tip on CT coordinate
        filename_7 = ['pa2-',x,'-',k,'-em-nav.txt'];
        table_nav = importdata(filename_7);
        data_nav = table_nav.data;
        textdata_nav = table_nav.textdata;
        Ng_nav = str2double(textdata_nav(1));
        N_frame2 = str2double(textdata_nav(2));
        
        Fmatrix2 = computeFCorrect(data_nav,coef_C, N_frame2, Ng_nav);
        % Pctip = Freg * Fg * Ptip = Freg * Bj
        res = [];
        for i=1:N_frame2
            F = Fmatrix2{i};
            [~,~,frameTr] = FrameTrans(Freg,F);
            [~,re] = TriDxform(frameTr, Ptip);
            res = [res;re'];
        end
        disp("position of pointer tip relative to the CT coordinate: ");
        disp(res);

        %%% Export data
        FULLDATA = [Ppivot Ppivot_opt expectC'];
        file_name = ['./OUTPUTS/pa2-real-',x,'-',k,'-output1.txt'];
        fileID = fopen(file_name,'wt+');
        fprintf(fileID,strcat('27, 125, ', file_name, '\n'));
        fprintf(fileID,'%.2f %.2f %.2f\n',FULLDATA);
        fclose(fileID);

        FULLDATA1 = res';
        file_name = ['./OUTPUTS/pa2-real-',x,'-',k,'-output2.txt'];
        fileID = fopen(file_name,'wt+');
        fprintf(fileID,strcat('4, ', file_name, '\n'));
        fprintf(fileID,'%.2f %.2f %.2f\n',FULLDATA1);
        fclose(fileID);
end


