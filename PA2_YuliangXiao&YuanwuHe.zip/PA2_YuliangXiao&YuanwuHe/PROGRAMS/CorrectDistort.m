%{  Make distortion correction on the input dataset by using Bernstein polynomials
%   Input: p(set of data with distortion), c(coefficient used in Bernstein polynomials), pmin(minimal vector in the dataset),pmax(maximum vector in the dataset)
%   Output: result(a set of data without distortion)
%}
function result = CorrectDistort(q, c, qmin, qmax)
    result = [];
    for m = 1:length(q)
        % give bounding box to each point
        u = ScaleToBox(q(m,:), qmin, qmax);
        correct = zeros(1,3);
        count = 1;
        % apply Bernstein polynomials
        for i = 0:5
            for j = 0:5
                for k = 0:5
                    correct = correct + c(count, :) * Bern(u(1), 5, i) * Bern(u(2), 5, j) * Bern(u(3), 5, k);
                    count = count + 1;
                end
            end
        end
        result = [result; correct];
    end
end
% compute Bernstein element 
function v = Bern(x, N, k)
    coef = factorial(N) / (factorial(N-k) * factorial(k));
    v = coef * (1-x)^(N-k) * x^k;
end