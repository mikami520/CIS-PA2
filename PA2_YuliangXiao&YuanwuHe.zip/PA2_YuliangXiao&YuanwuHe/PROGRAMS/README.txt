Programming Assignment 2 -- Yuliang Xiao & Yuanwu He

Instruction for runnning the program

1. Open the MATLAB and add the PROGRAMS folder, its subfolder and datatset folder to the path
2. Run the PA2.m to oeprate the program.
3. The result is displayed in the command window and OUTPUTS folder.
4. If you want to run the Unit Test program, open the Unittest.m file and run it. The output data is saved in TEST folder.